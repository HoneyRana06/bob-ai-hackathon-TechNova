Add at least 3 screenshots of the running app here before submission.
