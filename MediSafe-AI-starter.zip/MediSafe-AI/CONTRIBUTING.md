Keep the official template instructions and add team contribution details here.
