# MediSafe AI — Drug Interaction & Medication Safety Assistant

Educational prototype for the IBM BoB AI Innovation Hackathon 2026.

## Problem
Medication combinations can create potential risks that are difficult for learners and patients to understand when information is spread across multiple sources.

## Solution
MediSafe AI lets a user select medicines, checks pairwise combinations against a curated educational dataset, explains potential concerns, and generates a screening report for pharmacist or prescriber review.

## Features
- Medicine selection
- Pairwise interaction screening
- Severity and mechanism explanation
- Evidence source display
- Downloadable report
- Safety disclaimer

## Run locally

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Start the app:
```bash
streamlit run src/app.py
```

## Safety and limitations
This is an educational prototype. The included dataset is small and is not a complete clinical interaction database. It must not be used to make treatment decisions. Do not upload real patient data.

## IBM Bob integration
IBM Bob is used as an AI coding and software-development partner for planning, implementation, code review, testing, documentation, and future AI integration.
