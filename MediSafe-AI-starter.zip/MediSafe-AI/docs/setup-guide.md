# Setup Guide

## Prerequisites
- Python 3.10 or newer
- Internet connection for installing packages
- A computer with a terminal

## Installation
1. Open the project folder.
2. Create a virtual environment:
   `python -m venv .venv`
3. Activate it.
4. Install dependencies:
   `pip install -r requirements.txt`
5. Run:
   `streamlit run src/app.py`

## Verification
- The MediSafe AI page opens in a browser.
- At least two medicines can be selected.
- The Check interactions button displays results.
- The report tab generates a downloadable text file.

## Troubleshooting
| Problem | Fix |
|---|---|
| `streamlit` not found | Activate the virtual environment and run `pip install -r requirements.txt` |
| CSV not found | Run the command from the project root |
| Browser does not open | Copy the local URL shown in the terminal |
