# Architecture

```mermaid
flowchart TD
    A[User selects medicines] --> B[Streamlit interface]
    B --> C[Pairwise screening logic]
    C --> D[Curated interaction CSV]
    D --> E[Findings and source display]
    E --> F[Downloadable safety report]
```

| Component | Responsibility |
|---|---|
| Streamlit | User interface |
| Python | Screening logic |
| CSV dataset | Curated educational records |
| Report generator | Creates a text report |
| IBM Bob | Development, review, testing, and documentation support |

## Security notes
- Do not upload real patient information.
- Do not commit secrets.
- Keep the dataset source-linked.
- Treat all results as educational and require professional review.
