import streamlit as st
import pandas as pd
from itertools import combinations
from datetime import date

st.set_page_config(
    page_title="MediSafe AI",
    page_icon="💊",
    layout="wide",
)

st.markdown("""
<style>
    .main {background: #f7f9fc;}
    .hero {padding: 1.2rem 1.5rem; border-radius: 16px; background: linear-gradient(135deg,#173b6c,#247ba0); color: white;}
    .risk {padding: 1rem; border-radius: 12px; border-left: 6px solid #e0a000; background: #fff8e6;}
    .safe {padding: 1rem; border-radius: 12px; border-left: 6px solid #2e8b57; background: #edf9f1;}
    .small {color: #5d6878; font-size: 0.9rem;}
</style>
""", unsafe_allow_html=True)

DATA_PATH = Path(__file__).parent / "interactions.csv"

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

data = load_data()
drug_names = sorted(set(data["drug_a"]).union(set(data["drug_b"])))

st.markdown("""
<div class="hero">
<h1>💊 MediSafe AI</h1>
<p>Drug Interaction & Medication Safety Assistant</p>
<p class="small" style="color:#e5f3ff;">Educational prototype for the IBM BoB AI Innovation Hackathon 2026</p>
</div>
""", unsafe_allow_html=True)

st.warning(
    "Educational prototype only. This tool is not a medical device and does not replace "
    "a doctor, pharmacist, official product label, or validated clinical interaction checker. "
    "Never stop or change medicines based on this app."
)

tab1, tab2, tab3 = st.tabs(["🔎 Interaction Checker", "📄 Safety Report", "ℹ️ About the Project"])

with tab1:
    st.subheader("Select medicines")
    selected = st.multiselect(
        "Choose two or more medicines from the demo dataset",
        options=drug_names,
        placeholder="Search and select medicines..."
    )

    if st.button("Check interactions", type="primary", disabled=len(selected) < 2):
        findings = []
        for a, b in combinations(selected, 2):
            match = data[
                ((data["drug_a"] == a) & (data["drug_b"] == b)) |
                ((data["drug_a"] == b) & (data["drug_b"] == a))
            ]
            if not match.empty:
                findings.append(match.iloc[0].to_dict())

        st.session_state["selected"] = selected
        st.session_state["findings"] = findings

    if "findings" in st.session_state:
        findings = st.session_state["findings"]
        st.subheader("Screening results")
        if findings:
            for item in findings:
                st.markdown(f"""
                <div class="risk">
                <h4>⚠️ {item["drug_a"]} + {item["drug_b"]}</h4>
                <b>Severity:</b> {item["severity"]}<br><br>
                <b>Mechanism:</b> {item["mechanism"]}<br><br>
                <b>Clinical concern:</b> {item["clinical_concern"]}<br><br>
                <b>Suggested action:</b> {item["suggested_action"]}<br><br>
                <b>Evidence source:</b> {item["source"]}
                </div>
                """, unsafe_allow_html=True)
                st.write("")
        else:
            st.markdown("""
            <div class="safe">
            <h4>✅ No matching record found in this demo dataset</h4>
            This does not prove that the selected medicines are safe together.
            Confirm with a pharmacist or validated interaction reference.
            </div>
            """, unsafe_allow_html=True)

with tab2:
    st.subheader("Safety report")
    selected = st.session_state.get("selected", [])
    findings = st.session_state.get("findings", [])
    if not selected:
        st.info("Run an interaction check first to generate a report.")
    else:
        report_lines = [
            "MEDISAFE AI — EDUCATIONAL SCREENING REPORT",
            f"Report date: {date.today().isoformat()}",
            f"Medicines screened: {', '.join(selected)}",
            "",
            "IMPORTANT: Educational prototype only. Professional review is required.",
            ""
        ]
        if findings:
            for i, item in enumerate(findings, 1):
                report_lines += [
                    f"{i}. {item['drug_a']} + {item['drug_b']}",
                    f"Severity: {item['severity']}",
                    f"Mechanism: {item['mechanism']}",
                    f"Clinical concern: {item['clinical_concern']}",
                    f"Suggested action: {item['suggested_action']}",
                    f"Source: {item['source']}",
                    ""
                ]
        else:
            report_lines.append("No matching record found in the demo dataset.")
        report = "\n".join(report_lines)
        st.text_area("Report preview", report, height=350)
        st.download_button(
            "⬇️ Download report",
            data=report,
            file_name="medisafe_screening_report.txt",
            mime="text/plain"
        )

with tab3:
    st.subheader("About MediSafe AI")
    st.write("""
    MediSafe AI is a student-built educational prototype designed to demonstrate
    how structured medication information and AI-assisted explanations could support
    medication-safety learning and pharmacist review.
    """)
    st.markdown("""
    **Current scope**
    - Curated demo interaction records
    - Pairwise screening
    - Source-linked explanations
    - Downloadable report

    **Future scope**
    - Larger validated datasets
    - Drug-food and drug-condition screening
    - IBM watsonx.ai explanation layer
    - Pharmacist review workflow
    - Audit trail and role-based access
    """)
    st.info("IBM Bob can be used to explain, review, test, and improve the source code and documentation.")
