# Source Code

- `app.py`: Streamlit application
- `interactions.csv`: Small educational interaction dataset
- `requirements.txt`: Python dependencies
