Create slides.pdf or slides.pptx before submission.
